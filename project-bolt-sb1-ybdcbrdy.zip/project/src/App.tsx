import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { v4 as uuidv4 } from 'uuid';
import QRCode from 'qrcode';
import { FileUp, Download, HelpCircle, X, Edit2, Save } from 'lucide-react';
import { PDFDownloadLink, Document as PDFDocument, Page as PDFPage, Text, View, Image, StyleSheet } from '@react-pdf/renderer';
import mammoth from 'mammoth';
import { renderAsync } from 'docx-preview';
import 'react-pdf/dist/Page/AnnotationLayer.css';
import 'react-pdf/dist/Page/TextLayer.css';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

const styles = StyleSheet.create({
  page: {
    flexDirection: 'column',
    backgroundColor: '#ffffff',
    padding: 30,
  },
  qrCode: {
    position: 'absolute',
    top: 30,
    right: 30,
    width: 100,
    height: 100,
  },
  content: {
    width: '100%',
    height: '100%',
  },
});

const BulletinPDF = ({ qrCodeUrl, content }) => (
  <PDFDocument>
    <PDFPage size="A4" style={styles.page}>
      <View style={styles.content}>
        <div dangerouslySetInnerHTML={{ __html: content }} />
      </View>
      {qrCodeUrl && <Image src={qrCodeUrl} style={styles.qrCode} />}
    </PDFPage>
  </PDFDocument>
);

function App() {
  const [file, setFile] = useState<File | null>(null);
  const [content, setContent] = useState<string>('');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [copies, setCopies] = useState<number>(1);
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedBulletins, setGeneratedBulletins] = useState<Array<{ id: string, qrCode: string }>>([]);
  
  const previewRef = useRef<HTMLDivElement>(null);
  const editorRef = useRef<HTMLDivElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setFile(file);
    
    try {
      if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        // Traitement du fichier Word
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.convertToHtml({ arrayBuffer });
        setContent(result.value);
        
        if (previewRef.current) {
          await renderAsync(arrayBuffer, previewRef.current);
        }
      }
    } catch (error) {
      console.error('Erreur lors du chargement du fichier:', error);
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
    if (editorRef.current) {
      editorRef.current.innerHTML = content;
      editorRef.current.focus();
    }
  };

  const handleSave = () => {
    if (editorRef.current) {
      setContent(editorRef.current.innerHTML);
    }
    setIsEditing(false);
  };

  const generateQRCode = async (id: string): Promise<string> => {
    const verificationUrl = `https://geni-info.github.io/qr-code-verification/verification.html?id=${id}`;
    return await QRCode.toDataURL(verificationUrl, {
      color: {
        dark: '#000080',
        light: '#FFFFE0'
      }
    });
  };

  const generateBulletins = useCallback(async () => {
    if (!content) return;

    setIsGenerating(true);
    setProgress(0);
    const bulletins = [];

    try {
      for (let i = 1; i <= copies; i++) {
        const uniqueId = uuidv4();
        const qrCodeDataUrl = await generateQRCode(uniqueId);
        
        bulletins.push({
          id: uniqueId,
          qrCode: qrCodeDataUrl
        });
        
        setProgress((i / copies) * 100);
      }
      
      setGeneratedBulletins(bulletins);
    } catch (error) {
      console.error('Error generating bulletins:', error);
    }

    setIsGenerating(false);
  }, [copies, content]);

  return (
    <div className="min-h-screen bg-[#1a1a2e] text-white p-8">
      <header className="bg-[#0f3460] rounded-2xl p-6 mb-8">
        <h1 className="text-3xl font-bold text-[#e94560] text-center">
          Générateur de Bulletins
        </h1>
      </header>

      <button
        onClick={() => setShowGuide(!showGuide)}
        className="flex items-center gap-2 bg-[#e94560] hover:bg-[#bf3a4c] px-6 py-3 rounded-lg mx-auto mb-8"
      >
        <HelpCircle size={20} />
        Guide d'utilisation
      </button>

      {showGuide && (
        <div className="bg-[#16213e] rounded-2xl p-6 mb-8 relative">
          <button
            onClick={() => setShowGuide(false)}
            className="absolute top-4 right-4 text-gray-400 hover:text-white"
          >
            <X size={24} />
          </button>
          <h2 className="text-xl font-bold mb-4">Guide d'utilisation</h2>
          <ol className="list-decimal list-inside space-y-2">
            <li>Sélectionnez un fichier Word (.docx)</li>
            <li>Modifiez le contenu si nécessaire</li>
            <li>Indiquez le nombre de copies à générer</li>
            <li>Cliquez sur "Générer les bulletins"</li>
            <li>Téléchargez vos bulletins avec QR codes uniques</li>
          </ol>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-[#16213e] rounded-2xl p-6">
          <div className="mb-8">
            <label className="block text-lg mb-2">Fichier Word (.docx)</label>
            <div className="flex items-center gap-4">
              <label className="flex-1 cursor-pointer">
                <div className="flex items-center justify-center gap-2 border-2 border-dashed border-gray-500 rounded-lg p-4 hover:border-[#e94560] transition-colors">
                  <FileUp size={24} />
                  <span>{file ? file.name : 'Choisir un fichier'}</span>
                </div>
                <input
                  type="file"
                  accept=".docx"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="mb-8">
            <label className="block text-lg mb-2">Nombre de copies</label>
            <input
              type="number"
              min="1"
              value={copies}
              onChange={(e) => setCopies(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full bg-[#1a1a2e] border border-gray-600 rounded-lg px-4 py-2 text-white"
            />
          </div>

          {!isGenerating && generatedBulletins.length > 0 && content ? (
            <PDFDownloadLink
              document={<BulletinPDF qrCodeUrl={generatedBulletins[0].qrCode} content={content} />}
              fileName="bulletins.pdf"
              className="w-full bg-[#e94560] hover:bg-[#bf3a4c] px-6 py-3 rounded-lg flex items-center justify-center gap-2 text-white no-underline"
            >
              {({ loading }) => (
                <>
                  <Download size={20} />
                  {loading ? 'Préparation du PDF...' : 'Télécharger les bulletins'}
                </>
              )}
            </PDFDownloadLink>
          ) : (
            <button
              onClick={generateBulletins}
              disabled={!content || isGenerating}
              className="w-full bg-[#e94560] hover:bg-[#bf3a4c] disabled:bg-gray-600 px-6 py-3 rounded-lg flex items-center justify-center gap-2"
            >
              <Download size={20} />
              {isGenerating ? 'Génération en cours...' : 'Générer les bulletins'}
            </button>
          )}

          {isGenerating && (
            <div className="mt-4">
              <div className="h-2 bg-[#1a1a2e] rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#e94560] transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-center mt-2">{Math.round(progress)}%</p>
            </div>
          )}
        </div>

        <div className="bg-[#16213e] rounded-2xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Aperçu et Édition</h2>
            {content && (
              <button
                onClick={isEditing ? handleSave : handleEdit}
                className="flex items-center gap-2 bg-[#e94560] hover:bg-[#bf3a4c] px-4 py-2 rounded-lg"
              >
                {isEditing ? (
                  <>
                    <Save size={20} />
                    Sauvegarder
                  </>
                ) : (
                  <>
                    <Edit2 size={20} />
                    Modifier
                  </>
                )}
              </button>
            )}
          </div>
          
          <div className="bg-white rounded-lg p-4 min-h-[600px]">
            {isEditing ? (
              <div
                ref={editorRef}
                contentEditable
                className="w-full h-full min-h-[600px] text-black outline-none"
              />
            ) : content ? (
              <div
                ref={previewRef}
                className="w-full h-full min-h-[600px] text-black"
                dangerouslySetInnerHTML={{ __html: content }}
              />
            ) : (
              <div className="h-[600px] flex items-center justify-center text-gray-400">
                Aucun fichier sélectionné
              </div>
            )}
          </div>
        </div>
      </div>

      <footer className="text-center text-gray-400 mt-8">
        © Groupe Scolaire Hadja Fatou Diaby
      </footer>
    </div>
  );
}

export default App;